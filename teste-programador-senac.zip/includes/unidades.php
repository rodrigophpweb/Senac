<!-- Selecione a Unidade -->
<section id="interesses">
    <div class="container">
        <div class="row text-center pt-5 pb-5 mt-5" >
            <div class="col-lg-12 wow animated rubberBand">
                <h2>Selecione a unidade de seu interesse e faça a inscrição on-line</h2>
                <a href="" class="btn btn-outline-primary btn-lg">Senac Campinas</a>
                <a href="" class="btn btn-outline-primary btn-lg">Senac Lapa Tito</a>
                <a href="" class="btn btn-outline-primary btn-lg">Senac Jundiaí</a>
                <a href="" class="btn btn-outline-primary btn-lg">Senac Ribeiro Preto</a>
            </div>                
        </div>
    </div>
</section>