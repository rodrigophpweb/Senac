<!-- Bootstrap, Style e Animate -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    