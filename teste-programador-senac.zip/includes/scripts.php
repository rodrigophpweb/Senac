<!-- Arquivos JavaScript -->
<!-- jQuery, Popper.js, Bootstrap e WOW -->
<script src="assets/js/jquery-3.3.1.slim.min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/fontawesome.js"></script>
<script src="assets/js/wow.js"></script>
<script src="assets/js/wow.js"></script>
<script>
    new WOW().init();
</script>