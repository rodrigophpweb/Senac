<div class="col-md-12 col-lg-6 wow animated fadeInRight fotos">
    <div class="masked">
        <img src="assets/images/laboratorio.jpg" alt="Laboratório"  />
    </div>

    <div class="masked">
        <img src="assets/images/auditorio.jpg" alt="Auditório"  />
    </div>
</div>