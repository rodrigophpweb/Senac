<!-- Conteúdo Principal -->
<main>
    <?php include('includes/breadcrumb.php');?>
    <article class="container">
        <div class="row">
            <?php include('includes/o-curso.php');?>
            <?php include('includes/fotos.php');?>
            <?php include('includes/informacoes-sobre-o-curso.php');?>
        </div>
    </article>
</main>