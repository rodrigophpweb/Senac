<!-- Informações Comerciais -->
<section id="infos">
    <div class="container">
        <div class="row pt-5 pb-5">
            <div class="col-lg-10 mx-auto text-center">
                <h6>Senac - Serviço Nacional de Aprendizagem Comercial - CNPJ: <a>[consulte as unidades]</a> ou pelo <a>Fale Conosco</a></h6>
                <h6>Informações: <strong>4090-1030</strong> para capitais e regiões metropolitanas e <strong>0800-883-2000</strong> para demais regiões</h6>
            </div>
        </div>
    </div>
</section>